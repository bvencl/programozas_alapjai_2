#include <cstring>

class String
{
public:
    String(char const *str = "")
    {
        len = std::strlen(str);
        pData = new char[len+1];
        std::strcpy(pData, str);
    }

    ~String()
    {
        delete [] pData;
    }

    String(String const &rhs)
    {
        pData = nullptr;
        *this = rhs;
    }

    String &operator=(String const &rhs)
    {
        if (this == &rhs)
            return *this;
        delete [] pData;
        len = rhs.len;
        pData = new char[len+1];
        std::strcpy(pData, rhs.pData);
    }

private:
    char *pData;
    size_t len;
};

String f()
{
    return String("my favourite string");
}

int main()
{
    String c;
    c = f();
    return 0;
}
