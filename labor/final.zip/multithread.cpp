#include <thread>
#include <chrono>
#include <iostream>
#include <mutex>

bool ready = false;
int counter = 0;

void increase(int &counter)
{
    while (!ready)
    {
        counter++;
    }
}

void decrease()
{
    while (!ready)
    {
        counter--;
    }
}

void print()
{
    while (!ready)
    {
        std::cout << counter << ',';
    }
}

int main()
{

    return 0;
}
